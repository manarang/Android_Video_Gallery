<?php

require_once ("source.php");

   $result = array();
   $q1="SELECT * FROM video ORDER BY tahun DESC";
   $jl1= mysqli_query($db,$q1);
   while($video=mysqli_fetch_array($jl1)){
     array_push($result,array(
	'vid'     => $video['v_id'],
	'tahun'   => $video['tahun'],
	'genre'   => $video['genre'],
	'judul'   => $video['judul'],
	'tempat'  => $video['tempat'],
	));
    }
   echo json_encode(array('result' => $result));
   mysqli_close($db);
?>
   }
