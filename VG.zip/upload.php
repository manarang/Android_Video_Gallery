<?php
require_once ("source.php");
$hari=date('Ymd');
$id = $_GET['id'];
$kode = $_GET['kd'];
if(!isset($kode)){$kode=1;}

if(isset($_POST['masuk']))
  {
    $psw=$_POST['Password'];
    $usr=$_POST['UserName'];
    $q1="SELECT * FROM admin WHERE paswd='$psw' && u_name='$usr'";
    $jl1= mysqli_query($db,$q1);
    $row1=mysqli_fetch_array($jl1);
    if($row1[0]!=""){
       	$kode=2;
     }else{ 
             $error="Username atau Password salah!";
             $kode=1;        
     } 
   
  }

if(isset($_POST['upv']))
  {
    $i_genre =$_POST['genre'];
    $tahun   =$_POST['tahun'];
    $tahun   =str_replace(' ', '', $tahun);
    $judul   =$_POST['judul'];
    $name    =$_FILES['video']['name'];
    $ext     = pathinfo($name, PATHINFO_EXTENSION);
    $all_ext = array("mp4", "3gp", "mkv", "mpeg");
    $name = cfn($name);
    $q1 = "SELECT * FROM genre WHERE g_id='$i_genre'";
    $jl1= mysqli_query($db, $q1);
    $genre=mysqli_fetch_array($jl1);
    $tempat=$genre['gendir']."/".$name;
    if(in_array($ext, $all_ext)){

       if(move_uploaded_file($_FILES["video"]["tmp_name"], $tempat)){

         $q2="INSERT INTO video(genre,judul,tahun,tempat)VALUES('$i_genre','$judul','$tahun','$tempat')";
         $jl2=mysqli_query($db,$q2);
         $kode = 2;
       }
       
    }else{ 
        $error = "File format tidak didukung!";
        $kode=2;
    } 
  }  
?>

<!doctype html><head>
  <meta  charset=UTF-8' />
  <meta name='viewport' content='width=device-width'>
  <link rel='shortcut icon' href='/favicon.ico' type='image/x-icon' />
  <title>Upload</title>
  <link rel='stylesheet' type='text/css'  href='css/style.css' media='all' >
</head><body>
<div class='head-top'>
  <div class='menu'> 
   <div class='logo'><img src="img/logo.svg" ></div> 
   <div class='logo_2'><img src="img/smv.svg" ></div> 
   <div class='home'><a href='index.php' ><img src='img/back.svg' ></a></div>
   </div></div>

<?php
switch($kode){
  case 1: 
   echo "<div class='logincontent'>";
   echo "<div class='loginheading'>";
   echo "<span class='judul'>Login</span>";
   echo "<span class='blink'>".$error."</span>";
   echo "</div>";
   echo "<form action='upload.php' method='post'>";
   echo "<label>Username</label>";
   echo "<input type='text'  name='UserName' autofocus /><br/>";
   echo "<label>Password</label>";
   echo "<input type='password'  name='Password' /><br/>";
   echo "<input type='submit' class='loginbtn' value='Login'  name='masuk' /></form>";
   echo "</div>";
  break;

  case 2:
   echo "<div class='logincontent'>";
   echo "<div class='loginheading'>";
   echo "<span class='judul'>Upload Video</span>";
   echo "<span class='blink'>".$error."</span></div>";
   echo "<form action='upload.php' method='post' enctype='multipart/form-data'>";
   echo "<label>Pilih Genre</label><select class='input1' name='genre' required>";
   echo "<option value='' selected >Genre</option>";
   $q1="select * from genre";
   $jl1=mysqli_query($db, $q1);
   while($admin = mysqli_fetch_array($jl1)){
     echo "<option value='".$admin['g_id']."' >".$admin['genre']."</option>";
   }
   echo "</select><br/>";
   echo "<label>Tahun dibuat</label>";
   echo "<input class='input1' type='text' name='tahun' required ></br>";
   echo "<label>Judul Video</label>";
   echo "<input class='input1' type='text' name='judul' required ></br>";
   echo "<label>Video File</label>";
   echo "<input class='input1' type='file' name='video' required ></br>";
   echo "<input type='submit' class='loginbtn' value='Upload'  name='upv' onclick=\"return confirm('Mau upload?');\" />";
   echo "</form></div>"; 
    break;

}   
?>  


</body></html>
