<?php

?>
<!DOCTYPE html><head>
  <meta charset=UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" > 
  <link rel='shortcut icon' href='/favicon.ico' type='image/x-icon' />
  <title>Video Gallery</title>
  <link rel='stylesheet' type='text/css'  href='css/style.css' media='all' >
</head><body>
 <div class='head-top'>
   <div class='menu'>
     <div class='logo'><a href="admin.php" ><img src="img/logo.svg" ></a></div>
     <div class='logo_2'><img src="img/smv.svg" ></div>
     <div class='home'><a href="upload.php" ><img src="img/upload.svg" ></a>
     </div>
     <div class='home'><a href="lihat.php" ><img src="img/eye.svg" >
</div>
   </div>
 </div>
<img src="img/video.svg" >
</body></html>
