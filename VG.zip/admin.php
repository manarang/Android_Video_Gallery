<?php
require_once ("source.php");
$hari=date('Ymd');
$id = $_GET['id'];
$kode = $_GET['kd'];
if(!isset($kode)){$kode=1;}

if(isset($_POST['masuk']))
  {
    $psw=$_POST['Password'];
    $usr=$_POST['UserName'];
    $q1="SELECT * FROM admin WHERE paswd='$psw' && u_name='$usr'";
    $jl1= mysqli_query($db,$q1);
    $row1=mysqli_fetch_array($jl1);
    if($row1[0]!=""){
       	$kode=2;
     }else{ 
             $error="Username atau Password salah!";
             $kode=1;        
     } 
   
  }

if(isset($_POST['abu']))
  {
    $nama      =$_POST['nama'];
    $user      =$_POST['username'];
    $password  =$_POST['password'];
    $index     =$_POST['index'];
    $q2="UPDATE admin set name='$nama', u_name='$user', paswd='$password'  WHERE a_id=$index";
    $jl2=mysqli_query($db, $q2);
    $kode=2;
  }

if(isset($_POST['post']))
  {
    $index     =$_POST['index'];
    $q1="SELECT * FROM video WHERE v_id='$index'";
    $jl1= mysqli_query($db,$q1);
    $video=mysqli_fetch_array($jl1);
    unlink($video['tempat']);
    $q2="DELETE FROM video WHERE v_id=$index";
    $jl2=mysqli_query($db, $q2);
    $kode=2;
  }

?>

<!doctype html><head>
  <meta  charset=UTF-8' />
  <meta name='viewport' content='width=device-width'>
  <link rel='shortcut icon' href='/favicon.ico' type='image/x-icon' />
  <title>Admin</title>
  <link rel='stylesheet' type='text/css'  href='css/style.css' media='all' >
</head><body>
<div class='head-top'>
  <div class='menu'> 
   <div class='logo'><img src="img/logo.svg" ></div> 
   <div class='logo_2'><img src="img/smv.svg" ></div> 

<?php
switch($kode){
  case 1: 
   echo "<div class='home'><a href='index.php' ><img src='img/back.svg' ></a></div>";
   echo "</div></div>";
   echo "<div class='logincontent'>";
   echo "<div class='loginheading'>";
   echo "<span class='judul'>Admin Login</span>";
   echo "<span class='blink'>".$error."</span>";
   echo "</div>";
   echo "<form action='admin.php' method='post'>";
   echo "<label for='txtUserName'>Username&nbsp;</label>";
   echo "<input type='text'  name='UserName' autofocus /><br/>";
   echo "<label for='txtPassword'>Password&nbsp;</label>";
   echo "<input type='password'  name='Password' /><br/>";
   echo "<input type='submit' class='loginbtn' value='Login'  name='masuk' /></form>";
   echo "</div>";
  break;

  case 2: 
   echo "<div class='home'><a href='index.php' ><img src='img/back.svg' ></a></div>";
   echo "</div></div>";

    echo "<div class='logincontent'>";
    echo "<div class='menu'><a href='bgw.php' >";
    echo "<div class='menu'><a href='admin.php?kd=3' ><div class='loginbtn'>Edit Admin</div></a></div>";
    echo "<div class='menu'><a href='admin.php?kd=9' ><div class='loginbtn'>Hapus Posting</div></a></div>";    
    echo "</div>"; 
   break;

  case 3:
   echo "<div class='home'><a href='admin.php?kd=2' ><img src='img/back.svg' ></a></div>";
   echo "</div></div>";

    echo "<div class='logincontent'>";
    echo "<div class='loginheading'>Kelola Admin</div>";
    $q1="select * from admin";
    $jl1=mysqli_query($db, $q1);
    echo "<div class='red'>";
    echo "<div class='emet3'>Nama</div>";
    echo "<div class='emet3'>Username</div>";
    echo "<div class='emet3'>Password</div>";
    echo "<div class='emet4'></div>";
    echo "</div>";
    while($admin=mysqli_fetch_array($jl1))
    {
      echo "<div class='brown'>";
      echo "<div class='emet3'>".$admin[1]."</div>";
      echo "<div class='emet3'>".$admin[2]."</div>";
      echo "<div class='emet3'>".$admin[3]."</div>";
      echo "<div class='emet4'><a href='admin.php?kd=8&id=".$admin[0]."' >";
      echo "<img src='img/edit.svg' ></a></div>";      
      echo "</div>";
    }
    echo "</div>";
    break;

  case 8:
   echo "<div class='home'><a href='admin.php?kd=2' ><img src='img/back.svg' ></a></div>";
   echo "</div></div>";

   echo "<div class='logincontent'>";
   echo "<div class='loginheading'>Edit Admin</div>";
   $q2="select * from admin where a_id=$id";
   $jl2=mysqli_query($db, $q2);
   $admin = mysqli_fetch_array($jl2);
   echo "<form action='admin.php' method='post'>";
   echo "<label for='Nama'>Nama&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</label>";
   echo "<input type='text'  name='nama' value='".$admin[1]."' /><br/>";
   echo "<label for='txtUserName'>Username&nbsp;</label>";
   echo "<input type='text'  name='username' value='".$admin[2]."' /><br/>";
   echo "<label for='txtPassword'>Password&nbsp;</label>";
   echo "<input type='text'  name='password' value='".$admin[3]."' /><br/>";
   echo "<input type='hidden' value='".$admin[0]."'  name='index' />";
   echo "<div class='loginremember'>";
   echo "<input type='submit' class='loginbtn' value='Ubah'  name='abu' onclick=\"return confirm('Mau ubah?');\" />";
   echo "</form>";
   echo "</div>";
   break;  

  case 9:
   echo "<div class='home'><a href='admin.php?kd=2' ><img src='img/back.svg' ></a></div>";
   echo "</div></div>";

   echo "<div class='logincontent'>";
   echo "<div class='loginheading'>Hapus Posting</div>";
   $q2="select * from video";
   $jl2=mysqli_query($db, $q2);
    echo "<div class='red'>";
    echo "<div class='emet2'>Genre</div>";
    echo "<div class='emet2'>Tahun</div>";
    echo "<div class='emet1'>Judul</div>";
    echo "</div>";
    while($video=mysqli_fetch_array($jl2))
    {
      $q3="SELECT * FROM genre WHERE g_id='$video[1]'";
      $jl3= mysqli_query($db,$q3); 
      $n_genre=mysqli_fetch_array($jl3); 
      echo "<div class='brown'>";
      echo "<div class='emet2'>".$n_genre['genre']."</div>";
      echo "<div class='emet2'>".$video['tahun']."</div>";
      echo "<div class='emet1'>".$video['judul']."</div>";
      echo "<div class='emet4'><a href='admin.php?kd=10&id=".$video['v_id']."' ><img src='img/trash.svg' ></a></div>";
      echo "</div>";
    }
    echo "</div>";
    break;

  case 10:
   echo "<div class='home'><a href='admin.php?kd=2' ><img src='img/back.svg' ></a></div>";
   echo "</div></div>";

   echo "<div class='brown'>";
   echo "<div class='loginheading'>Hapus Video</div>";
   $q2="select * from video where v_id=$id";
   $jl2=mysqli_query($db, $q2);
   $video = mysqli_fetch_array($jl2);

   echo "<form action='admin.php' method='post'>";
   echo "<div class='red'><div class='emet2'>".$video['tahun']."</div></div>";
   echo "<div class='red'><div class='emet1'>".$video['judul']."</div></div>";
   echo "<input type='hidden' value='".$id."'  name='index' />";
   echo "<input type='submit' class='loginbtn' value='Hapus'  name='post' onclick=\"return confirm('Mau hapus?');\" />";
   echo "</form>";
   echo "</div>";
   break;

}   
?>  


</body></html>
