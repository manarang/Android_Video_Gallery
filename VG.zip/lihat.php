<?php
require_once ("source.php");
$id = $_GET['id'];
$kode = $_GET['kd'];
if(!isset($kode)){$kode=1;}

if(isset($_POST['cavi']))
  {
    $genre  =$_POST['genre'];
    $kode=2;
  }

?>

<!doctype html><head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
  <meta name="viewport" content="width=device-width"> 
  <link rel='shortcut icon' href='/favicon.ico' type='image/x-icon' />
  <title>Lihat</title>
  <link rel='stylesheet' type='text/css'  href='css/style.css' media='all' >
</head><body>
 <div class='head-top'>
  <div class='menu'>
    <div class='logo'><img src='img/logo.svg' ></div> 
   <div class='logo_2'><img src="img/smv.svg" ></div> 
    <div class='home'><a href='index.php' ><img src='img/back.svg' ></a></div>
  </div>
 </div>
<?php 
switch($kode){
  case 1: 
   echo "<div class='logincontent'>";
   echo "<div class='loginheading'>";
   echo "<span class='judul'>Lihat Video</span>";
   echo "<span class='blink'>".$error."</span>";
   echo "</div>";
   echo "<form action='lihat.php' method='post'>";
   echo "<label>Pilih Genre</label>";
   echo "<select class='input1' name='genre' required >";
   echo "<option value='' selected>Pilih Genre</option>";
   $qu="SELECT * FROM genre";
   $jlu = mysqli_query($db, $qu);
   while($u_name=mysqli_fetch_array($jlu)){
     
      echo "<option value='".$u_name[g_id]."' >".$u_name['genre']."</option>";
   }  
   echo "</select><br/>";
   echo "<input type='submit' class='loginbtn' value='Cari video'  name='cavi' />";
   echo "</form></div>";
  break;

  case 2: 
    $q1="SELECT * FROM video WHERE genre='$genre' ORDER BY tahun DESC";
    $jl1= mysqli_query($db,$q1);  
    echo "<div class='logincontent'>";
    echo "<div class='loginheading'>Daftar Video</div>";
    echo "<div class='red'>";
    echo "<div class='emet2'>Genre</div>";
    echo "<div class='emet2'>Tahun</div>";
    echo "<div class='emet1'>Judul</div></div>";
    while($video=mysqli_fetch_array($jl1)){
    echo "<div class='green'>";
    $q2="SELECT * FROM genre WHERE g_id='$video[1]'";
    $jl2= mysqli_query($db,$q2); 
    $n_genre=mysqli_fetch_array($jl2); 

      echo "<div class='emet2'>".$n_genre['genre']."</div>";
      echo "<div class='emet2'>".$video['tahun']."</div>";
      echo "<div class='emet1'>".$video['judul']."</div>";
      echo "<div class='emet4'><a href='".$video['tempat']."' ><img src='img/lihat.svg'></a></div>";
      echo "<div>";  
    }
      echo "</div>"; 
   break; 

  case 3:  
    $q1="SELECT * FROM video WHERE v_id=$id";
    $jl1= mysqli_query($db,$q1);
    $video=mysqli_fetch_array($jl1);
    

   break;

}

?>
</body></html>
