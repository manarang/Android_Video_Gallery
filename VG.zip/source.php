<?phP

try {
        $db = mysqli_connect("localhost","ido", "Sc4915>?#^krg", "video");
    } catch (mysqli_sql_exception $e) { // Failed to connect? Lets see the exception details..
        echo "MySQLi Error Code: " . $e->getCode() . "<br />";
        echo "Exception Msg: " . $e->getMessage();
        exit; // exit and close connection.
    }

  function cfn($filename){
     $bad = array(' ','-','/','à','á','ä','ã','â','ª','ç','è','é','ê','ë','ì','í','î','ï','ò','ó','õ','ô','ö',
        		'ñ','ù','ú','û','ü',"<!--","-->","'","<",">",'"','&','$','=',';','?',"%20","%22",    
			"%3c","%253c","%3e","%0e","%28","%29","%2528","%26","%24","%3f","%3b","%3d",'(',')');
     $filename = str_replace($bad, '', $filename);
     return stripslashes($filename);
   }

  function ltgl($tanggal) {
      If ($tanggal) {
            $tanggal  = str_replace("-", "", $tanggal);
            $hari   = substr($tanggal, 6, 2);
            $bulan = substr($tanggal, 4, 2);
            $tahun  = substr($tanggal, 0, 4);
            $tanggal  = "$hari-$bulan-$tahun";
      }
      return $tanggal;
  }

?>
